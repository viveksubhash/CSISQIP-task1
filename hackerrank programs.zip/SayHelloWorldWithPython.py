if __name__ == '__main__':
    print "Hello, World!"

Q:https://www.hackerrank.com/challenges/py-hello-world/problem