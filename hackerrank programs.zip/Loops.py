if __name__ == '__main__':
    n = int(raw_input())
    for i in range(0,n):
        print(i**2)


Q:https://www.hackerrank.com/challenges/python-loops/problem
