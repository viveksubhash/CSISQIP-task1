from __future__ import division

if __name__ == '__main__':
    a = int(raw_input())
    b = int(raw_input())
    print(a//b)
    print(a/b)

Q:https://www.hackerrank.com/challenges/python-division/problem
